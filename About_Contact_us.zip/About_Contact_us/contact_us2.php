<?php include 'sendemail.php' ; ?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Contact us</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css" integrity="sha384-wESLQ85D6gbsF459vf1CiZ2+rr+CsxRY0RpiF1tLlQpDnAgg6rwdsUF1+Ics2bni" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="style.css">
        

    </head>
    <body>
        <?php echo $alert;?>
        <section class="contact">
            <div class="content">
                <h2>Contact Us</h2>
                
            </div>
            <div class="container">
                <div class="contactInfo">
                    <div class="box">
                        <div class="icon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                        <div class="text">
                        <h3>Address</h3>
                        <p>Vadodara</p>
                        </div>
                    </div>
                    <div class="box">
                        <div class="icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
                        <div class="text">
                        <h3>Phone</h3>
                        <p>Vadodara</p>
                        </div>
                    </div>
                    <div class="box">
                        <div class="icon"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>
                        <div class="text">
                        <h3>Email</h3>
                        <p>Vadodara</p>
                        </div>
                    </div>
                </div>
                <div class="contactForm">
                    <form >
                        <h2>Send Message</h2>
                        <div class="inputBox">
                            <input type="text" name="name" required="required" >
                            <span>Full Name</span>
                        </div>
                        <div class="inputBox">
                            <input type="text" name="email" required="required" >
                            <span>Email</span>
                        </div>
                        <div class="inputBox">
                            <textarea required="required" name="text"></textarea>
                            <span>Type Your Message</span>
                        </div>
                        <div class="inputBox">
                            <input type="submit" name="Send" value="Send" >
                            
                        </div>
                    </form>
                </div>
               
            </div>
        </section>
        <script type="text/javascript">
        if(window.history.replaceState){
            window.history.replaceState(null,null,window.location.href);
        }
        </script>
    </body>
</html>